import express, { Request, Response } from 'express';
import formidable from "formidable";
import fs from "fs/promises";
import { BlobServiceClient } from "@azure/storage-blob";
import cors from "cors";
import uploadRouter from "../src/routes/upload.ts";
// Initialize the Express application
const app = express();
const port = process.env.PORT || 8888; 


// Middleware to parse incoming JSON payloads
app.use(express.json());
app.use("/api", uploadRouter);
app.use(
  cors({
    origin: "*", // or specific domains like ["https://yourfrontend.vercel.app"]
    methods: "*",
  })
);
// Define a simple GET route
app.get('/', (req: Request, res: Response) => {
  console.log('Hello from Express and TypeScript!');
  res.json('<h1>Hello from Express and TypeScript! Connection Successful.</h1>');
});

// Start the server
app.listen(port, () => {
  console.log(`⚡️ Server is running at http://localhost:${port}`);
});