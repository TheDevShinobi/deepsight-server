import express, { Request, Response } from "express";
import formidable, { Files, Fields } from "formidable";
import fs from "fs/promises";
import { BlobServiceClient } from "@azure/storage-blob";

const router = express.Router();

const CONNECTION_STRING =
  "DefaultEndpointsProtocol=https;AccountName=civicnav;AccountKey=Mr/3EOim7egTen6NbozS4hdCx5AX4l175jpNcFKJctMbSKSnjHdBS6ttolH7j9Z14RwPZu3MbuM2+AStC3K+MA==;EndpointSuffix=core.windows.net";
const CONTAINER_NAME = "portcontainer";

router.get('/yes', async(req:Request, res: Response) => {
  return res.json({'message':'hello from express'})
})

router.post("/upload", async (req: Request, res: Response) => {
  try {
    const form = formidable({ multiples: false });

    form.parse(req, async (err: any, fields: Fields, files: Files) => {
      if (err) {
        console.error("Form parse error:", err);
        return res.status(400).json({ error: "File parsing failed" });
      }

      // Formidable v3 returns arrays for files
      const file = Array.isArray(files.file) ? files.file[0] : (files.file as any);

      if (!file) {
        return res.status(400).json({ error: "No file provided" });
      }

      const blobServiceClient = BlobServiceClient.fromConnectionString(CONNECTION_STRING);
      const containerClient = blobServiceClient.getContainerClient(CONTAINER_NAME);
      await containerClient.createIfNotExists({ access: "container" });

      const blobClient = containerClient.getBlockBlobClient(
        file.originalFilename || file.newFilename
      );

      const buffer = await fs.readFile(file.filepath);

      await blobClient.uploadData(buffer, {
        blobHTTPHeaders: {
          blobContentType: file.mimetype || "application/octet-stream",
        },
      });

      return res.status(200).json({ url: blobClient.url });
    });
  } catch (error: any) {
    console.error("Upload error:", error);
    return res.status(500).json({
      error: "Upload failed",
      details: error.message,
    });
  }
});

export default router;
