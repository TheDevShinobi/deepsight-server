"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const formidable_1 = __importDefault(require("formidable"));
const promises_1 = __importDefault(require("fs/promises"));
const storage_blob_1 = require("@azure/storage-blob");
const router = express_1.default.Router();
const CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=civicnav;AccountKey=Mr/3EOim7egTen6NbozS4hdCx5AX4l175jpNcFKJctMbSKSnjHdBS6ttolH7j9Z14RwPZu3MbuM2+AStC3K+MA==;EndpointSuffix=core.windows.net";
const CONTAINER_NAME = "portcontainer";
router.get('/yes', async (req, res) => {
    return res.json({ 'message': 'hello' });
});
router.post("/upload", async (req, res) => {
    try {
        const form = (0, formidable_1.default)({ multiples: false });
        form.parse(req, async (err, fields, files) => {
            if (err) {
                console.error("Form parse error:", err);
                return res.status(400).json({ error: "File parsing failed" });
            }
            // Formidable v3 returns arrays for files
            const file = Array.isArray(files.file) ? files.file[0] : files.file;
            if (!file) {
                return res.status(400).json({ error: "No file provided" });
            }
            const blobServiceClient = storage_blob_1.BlobServiceClient.fromConnectionString(CONNECTION_STRING);
            const containerClient = blobServiceClient.getContainerClient(CONTAINER_NAME);
            await containerClient.createIfNotExists({ access: "container" });
            const blobClient = containerClient.getBlockBlobClient(file.originalFilename || file.newFilename);
            const buffer = await promises_1.default.readFile(file.filepath);
            await blobClient.uploadData(buffer, {
                blobHTTPHeaders: {
                    blobContentType: file.mimetype || "application/octet-stream",
                },
            });
            return res.status(200).json({ url: blobClient.url });
        });
    }
    catch (error) {
        console.error("Upload error:", error);
        return res.status(500).json({
            error: "Upload failed",
            details: error.message,
        });
    }
});
exports.default = router;
